import {matchingQuestions,requestedCount} from './practice-core.mjs';

export function selectMockQuestions(questions,filters,{domains,isDue,latest,random=Math.random}={}){
  const pool=matchingQuestions(questions,filters,{isDue,latest,scoredOnly:true});
  const count=Math.min(requestedCount(filters.count),pool.length);
  const buckets=new Map(domains.map(d=>[d.id,pool.filter(q=>q.domain===d.id).sort((a,b)=>a.id-b.id)]));
  if(filters.order==='random')for(const bucket of buckets.values())for(let i=bucket.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[bucket[i],bucket[j]]=[bucket[j],bucket[i]];}
  const weighted=filters.domain==='all';
  const desired=domains.map(d=>({id:d.id,target:count*d.weight/100,allocated:0,capacity:buckets.get(d.id).length}));
  if(weighted)for(const d of desired)d.allocated=Math.min(d.capacity,Math.floor(d.target));
  let left=count-desired.reduce((n,d)=>n+d.allocated,0);
  while(left>0){const next=desired.filter(d=>d.allocated<d.capacity).sort((a,b)=>weighted?(b.target-b.allocated)-(a.target-a.allocated)||a.id-b.id:a.id-b.id)[0];if(!next)break;next.allocated++;left--;}
  let selected=desired.flatMap(d=>buckets.get(d.id).slice(0,d.allocated));
  if(filters.order==='random')for(let i=selected.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[selected[i],selected[j]]=[selected[j],selected[i]];}else selected.sort((a,b)=>a.id-b.id);
  return {ids:selected.map(q=>q.id),blueprint:{weighted,counts:Object.fromEntries(desired.map(d=>[d.id,d.allocated])),weights:Object.fromEntries(domains.map(d=>[d.id,d.weight])),sourceKeyCount:selected.filter(q=>q.feedbackMode==='source-key').length,
    constrained:weighted&&desired.some(d=>d.allocated<Math.floor(d.target))}};
}
