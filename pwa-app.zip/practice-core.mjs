export const defaultFilters=()=>({text:'',domain:'all',mode:'all',count:120,order:'sequential',type:'all'});

export function requestedCount(value){
  const text=String(value).trim();
  if(!/^\d+$/.test(text))return 0;
  const n=Number(text);return Number.isSafeInteger(n)&&n>0?n:0;
}

export function matchingQuestions(questions,filters,{isDue=()=>false,latest={},scoredOnly=false}={}){
  const f={...defaultFilters(),...filters};
  const text=f.text.trim().toLowerCase();
  return questions.filter(q=>
    (!scoredOnly||q.eligible)&&
    (f.domain==='all'||q.domain===Number(f.domain))&&
    (f.type==='all'||(f.type==='image'?!!q.visual:q.type===f.type))&&
    (f.mode==='all'||(f.mode==='due'?isDue(q):f.mode==='unseen'?!latest[q.id]:f.mode==='wrong'?latest[q.id]?.correct===false:false))&&
    (!text||`${q.id} ${q.stem.en} ${q.stem.zh} ${q.topic}`.toLowerCase().includes(text))
  );
}

export function selectQuestions(questions,filters,options={}){
  const f={...defaultFilters(),...filters};
  const selected=matchingQuestions(questions,f,options).sort((a,b)=>a.id-b.id);
  if(f.order==='random'){
    const random=options.random||Math.random;
    for(let i=selected.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[selected[i],selected[j]]=[selected[j],selected[i]];}
  }
  return f.count==='all'?selected:selected.slice(0,requestedCount(f.count));
}

export function isCurrentScored(question,attempt){
  return !!(question?.eligible&&attempt&&attempt.eligible!==false&&typeof attempt.correct==='boolean'&&(!question.contentVersion||attempt.contentVersion===question.contentVersion));
}

export function domainProgress(questions,attempts,domain){
  const bank=questions.filter(q=>q.domain===domain),scored=bank.filter(q=>q.eligible);
  const latest={};
  for(const a of attempts){if(!latest[a.qid]||Date.parse(a.at)>=Date.parse(latest[a.qid].at))latest[a.qid]=a;}
  const secure=scored.filter(q=>isCurrentScored(q,latest[q.id])&&latest[q.id].correct&&latest[q.id].confidence==='sure').length;
  return {total:scored.length,secure,percent:scored.length?Math.round(100*secure/scored.length):0,
    attempted:bank.filter(q=>latest[q.id]).length,available:bank.length};
}
