export function createMock(ids,id,now=Date.now()){
  if(!ids.length||new Set(ids).size!==ids.length)throw Error('A mock needs unique questions');
  return {id,ids:[...ids],index:0,responses:{},confidences:{},seconds:{},
    startedAt:now,durationMinutes:ids.length,deadline:now+ids.length*60000,viewed:now,finished:false};
}

export function cleanStudyState(defaults,{userId='local-device',bankId,revision=0,generation=0}={}){
  return {userId,bankId,attempts:[],preferences:structuredClone(defaults),revision,generation,dirty:false,synced:[]};
}
