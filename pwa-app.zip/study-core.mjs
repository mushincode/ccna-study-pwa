export const MAX_SESSIONS=12;
export function normalizePreferences(input,fallback={hours:8,times:['09:00','11:30','15:00','20:00'],sessionCount:4,examDate:'2026-11-11',lang:'en'}){
  const p={...fallback,...input};
  const count=input?.sessionCount??input?.times?.length??fallback.sessionCount;
  if(!Number.isInteger(count)||count<1||count>MAX_SESSIONS)throw Error('Invalid session count');
  if(!Number.isFinite(p.hours)||p.hours<0.25||p.hours>16)throw Error('Invalid daily hours');
  if(!Array.isArray(p.times)||p.times.length!==count||p.times.some(t=>typeof t!=='string'||!/^([01]\d|2[0-3]):[0-5]\d$/.test(t)))throw Error('Invalid session times');
  if(!['en','zh'].includes(p.lang)||typeof p.examDate!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(p.examDate)||!Number.isFinite(Date.parse(p.examDate))||new Date(p.examDate).toISOString().slice(0,10)!==p.examDate)throw Error('Invalid language or date');
  return {hours:p.hours,sessionCount:count,times:[...p.times],examDate:p.examDate,lang:p.lang};
}
export function sessionMinutes(hours,count){
  const total=Math.round(hours*60),base=Math.floor(total/count),extra=total%count;
  return Array.from({length:count},(_,i)=>base+(i<extra?1:0));
}
export function resizeTimes(times,count){
  if(times.length===count)return [...times];
  const minutes=t=>Number(t.slice(0,2))*60+Number(t.slice(3));
  const start=minutes(times[0]||'09:00'),last=minutes(times.length>1?times.at(-1):'20:00');
  const end=Math.max(start,last);
  return Array.from({length:count},(_,i)=>{const m=count===1?start:Math.round(start+(end-start)*i/(count-1));return String(Math.floor(m/60)).padStart(2,'0')+':'+String(m%60).padStart(2,'0');});
}
const bilingual=value=>typeof value==='object'&&value?`${value.en}\n${value.zh}`:String(value??'');
export function buildFollowUp(question,attempt,examName='CCNA 200-301'){
  const q=question,parts=[`Please help me understand ${examName} Q${q.id}. Answer in English and Traditional Chinese. / 請用英文及繁體中文協助我理解此題。`,
    'Question / 題目\n'+bilingual(q.stem),'Type / 題型: '+({single:'Single choice / 單選',multi:'Multiple choice / 多選',match:'Drag and drop / 拖放配對',reference:'Lab / source reference / 實作或來源對照'})[q.type]];
  for(const visual of [q.visual,...(q.media||[]),...(q.answerMedia||[])].filter(Boolean)){
    parts.push('Detailed image description / 詳細圖片描述\n'+bilingual(visual.description));
    for(const block of visual.evidence||[])parts.push(bilingual(block.label)+'\n'+block.content);
    if(visual.elements?.length)parts.push('Shown elements / 圖中元素\n'+visual.elements.map(e=>`${e.id}: ${bilingual(e.label)}${e.addresses?.length?'\nAddresses / 位址: '+e.addresses.join(', '):''}`).join('\n'));
    if(visual.connections?.length)parts.push('Shown connections / 圖中連線\n'+visual.connections.map(e=>`${e.from} → ${e.to}: ${bilingual(e.label)}`).join('\n'));
    parts.push(`Image asset / 圖片檔案: ${visual.image}\nNo image is attached to this text. / 此純文字未附圖片。`);
    if(visual.reviewState==='ocr-only')parts.push('OCR-only image description: connections and arrows are not verified. Do not invent missing topology details; request the original image if needed. / 圖片描述目前只經文字辨識，連線及箭頭尚未核實；不要虛構缺少的拓樸，必要時要求查看原圖。');
  }
  if(q.type==='match'){
    parts.push('Draggable items / 可拖放項目\n'+q.items.map(i=>`[${i.id}] ${bilingual(i.text)}`).join('\n'));
    parts.push('Available targets / 可配對目標\n'+q.targets.map((v,i)=>`${i+1}. ${q.targetLabels?bilingual(q.targetLabels[v]):v}`).join('\n'));
    parts.push('My matching response / 我的配對\n'+q.items.map(i=>`[${i.id}] → ${attempt?.response?.[i.id]||'Not answered / 未作答'}`).join('\n'));
    parts.push((q.status?.startsWith('imported')?'Unreviewed source mapping / 未核實來源配對\n':q.feedbackMode==='reference'?'Reviewed mapping with source limitations / 已核對配對及原題限制\n':'Reviewed mapping and reasons / 已核對的配對及原因\n')+q.items.map(i=>`[${i.id}] → ${i.target??'Not resolved / 未核實'}\n${bilingual(i.reason)}`).join('\n'));
  }else if(q.type==='reference'){
    parts.push('My lab notes / 我的實作筆記\n'+(attempt?.response?.[0]||'Not recorded / 尚未記錄'));
  }else{
    parts.push('Answer options / 答案選項\n'+q.options.map(o=>`${o.id}. ${bilingual(o.text)}`).join('\n'));
    parts.push('My response / 我的答案: '+(attempt?.response?.join(', ')||'Not answered / 未作答'));
    parts.push((q.status?.startsWith('imported')?'PDF answer key — unverified / PDF 答案鍵—未核實: ':q.review?.decision==='conditional-or-defective-wording'?'Conditional candidate, not a unique valid answer / 有條件候選，並非唯一無歧義答案: ':'Reviewed answer / 已核對答案: ')+q.answer.join(', '));
    parts.push('Option reasoning / 選項原因\n'+q.options.map(o=>`${o.id}: ${bilingual(q.rationale[o.id])}`).join('\n'));
  }
  if(attempt)parts.push('My confidence / 我的信心: '+({sure:'Confident / 有把握',unsure:'Uncertain / 不確定',guess:'Guessing / 猜測'})[attempt.confidence]);
  if(q.labGuide)parts.push('Lab solution and verification / 實作解法與驗證\n'+bilingual(q.labGuide));
  if(attempt?.needsPracticeAgain||q.contentVersion&&attempt&&attempt.contentVersion!==q.contentVersion)parts.push('The saved response is from an earlier question version. Do not assume its matching IDs refer to current card text; compare the old record carefully. / 已存作答來自較早版本，不能假設配對 ID 對應目前卡片文字，須先核對舊紀錄。');
  if(q.note)parts.push('Source caveat / 來源問題\n'+bilingual(q.note));
  if(q.sourceExplanation)parts.push('Original PDF discussion — unverified / PDF 原文討論—未核實\n'+q.sourceExplanation);
  if(q.communityVote)parts.push('Discussion vote / 討論投票: '+q.communityVote.answer.join(',')+' ('+q.communityVote.percent+'%)');
  parts.push('Quick method / 快速判斷\n'+bilingual(q.quick),'Why this answer / 為何正確\n'+bilingual(q.why));
  parts.push('Sources / 來源\n'+q.refs.map(r=>`${r.title}: ${r.url}`).join('\n'));
  parts.push('My follow-up question / 我的追問: ');
  return parts.join('\n\n');
}
